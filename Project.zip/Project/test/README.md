# learn-flask-with-tim-2
🌶 Learn Flask with Tech With Tim's Channel with make a simple posts website.


https://user-images.githubusercontent.com/75721128/144252921-52a1b750-6b78-4843-be69-b2f9415af45d.mp4

